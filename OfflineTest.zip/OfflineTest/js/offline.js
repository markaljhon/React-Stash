// Requires jQuery !!!

function OfflineSupported() {
	if (window.applicationCache) {
		alert('Offline Mode Supported.');
		return true;
	}
	else {
		alert('Offline Mode Not Supported.');
		return false;
	}
}

function Online() {
	if (navigator.onLine) {
		return true;
	}
	else {
		return false;
	}
}

$(window).bind('online', function() {
	alert('Now Online.');
});

$(window).bind('offline', function() {
	alert('Now Offline.');
});