$(function() {
	OfflineSupported();

	if (Online) {
		alert('You are online.');
	}
	else {
		alert('Your are offline');
	}
});